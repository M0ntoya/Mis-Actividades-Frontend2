// App.jsx

import React, { useState, useMemo, useEffect } from 'react';
import Header from './components/Header';
import ClickerButton from './components/ClickerButton';
import UpgradeList from './components/upgradeList';
import AyudanteList from './components/AyudanteList';
import './App.css';

const initialGameState = {
  birria: {
    id: 'birria',
    nombre: 'Birria',
    precioBase: 6,
    tacosVendidos: 0,
    isUnlocked: false,
    unlockCost: 200000,
    upgrades: [
      { id: 'birria-1', nombre: 'Salsa Borracha', nivel: 0, costoBase: 1000, costo: 1000, efecto: 0.1 },
      { id: 'birria-2', nombre: 'Tortilla de Maíz Azul', nivel: 0, costoBase: 2500, costo: 2500, efecto: 0.2 },
      { id: 'birria-3', nombre: 'Consomé', nivel: 0, costoBase: 5000, costo: 5000, efecto: 0.3 },
    ],
    ayudantes: [
      { id: 'birria-ayudante-1', nombre: 'Don Memo', nivel: 0, costoBase: 3000, costo: 3000, descripcion: 'Genera 2 tacos por segundo por nivel.' },
      { id: 'birria-ayudante-2', nombre: 'La Güera', nivel: 0, costoBase: 12000, costo: 12000, descripcion: 'Duplica el TPS total de Birria por nivel.' }
    ]
  },

  chorizo: {
    id: 'chorizo',
    nombre: 'Chorizo',
    precioBase: 8,
    tacosVendidos: 0,
    isUnlocked: false,
    unlockCost: 300000,
    upgrades: [
      { id: 'chorizo-1', nombre: 'Chicharrón', nivel: 0, costoBase: 2000, costo: 2000, efecto: 0.25 },
      { id: 'chorizo-2', nombre: 'Longaniza', nivel: 0, costoBase: 5000, costo: 5000, efecto: 0.35 },
      { id: 'chorizo-3', nombre: 'Tortilla Dorada', nivel: 0, costoBase: 10000, costo: 10000, efecto: 0.5 },
    ],
    ayudantes: [
      { id: 'chorizo-ayudante-1', nombre: 'El Jarocho', nivel: 0, costoBase: 4000, costo: 4000, descripcion: 'Genera 1.5 tacos por segundo por nivel.' },
      { id: 'chorizo-ayudante-2', nombre: 'La Negra', nivel: 0, costoBase: 15000, costo: 15000, descripcion: 'Duplica TPS de Chorizo por nivel.' }
    ]
  },

  asada: {
    id: 'asada',
    nombre: 'Asada',
    precioBase: 5,
    tacosVendidos: 0,
    isUnlocked: true,
    unlockCost: 0,
    upgrades: [
      { id: 'asada-1', nombre: 'Cebolla', nivel: 0, costoBase: 250, costo: 250, efecto: 0.15 },
      { id: 'asada-2', nombre: 'Cilantro', nivel: 0, costoBase: 2000, costo: 2000, efecto: 0.25 },
      { id: 'asada-3', nombre: 'Salsa', nivel: 0, costoBase: 5000, costo: 5000, efecto: 0.40 },
      { id: 'asada-4', nombre: 'Guacamole', nivel: 0, costoBase: 10000, costo: 10000, efecto: 0.55 },
      { id: 'asada-5', nombre: 'Doble Tortilla', nivel: 0, costoBase: 50000, costo: 50000, efecto: 0.70 },
    ],
    ayudantes: [
      { id: 'asada-ayudante-1', nombre: 'Don Chema', nivel: 0, costoBase: 1500, costo: 1500, descripcion: 'Genera 1 Taco por Segundo por nivel.' },
      { id: 'asada-ayudante-2', nombre: 'Doña Concha', nivel: 0, costoBase: 10000, costo: 10000, descripcion: 'Duplica el TPS total por cada nivel.' },
    ]
  },

  lengua: {
    id: 'lengua',
    nombre: 'Lengua',
    precioBase: 7,
    tacosVendidos: 0,
    isUnlocked: false,
    unlockCost: 100000,
    upgrades: [
      { id: 'lengua-1', nombre: 'Chicharrón Prensado', nivel: 0, costoBase: 30, costo: 30, efecto: 0.2 },
      { id: 'lengua-2', nombre: 'Salsa Roja', nivel: 0, costoBase: 40, costo: 40, efecto: 0.3 },
      { id: 'lengua-3', nombre: 'Limoncito', nivel: 0, costoBase: 40, costo: 40, efecto: 0.4 },
      { id: 'lengua-4', nombre: 'Cuerito', nivel: 0, costoBase: 80, costo: 80, efecto: 0.5 },
      { id: 'lengua-5', nombre: 'Guacamole Especial', nivel: 0, costoBase: 150, costo: 150, efecto: 0.6 },
    ],
    ayudantes: [
      { id: 'lengua-ayudante-1', nombre: 'Don Pancho', nivel: 0, costoBase: 5000, costo: 5000, descripcion: 'Genera 1 taco por segundo por nivel.' },
      { id: 'lengua-ayudante-2', nombre: 'La Cuerita', nivel: 0, costoBase: 20000, costo: 20000, descripcion: 'Duplica el TPS de Lengua por nivel.' }
    ]
  }
};

export default function App() {
  const [dinero, setDinero] = useState(0);
  const [gameState, setGameState] = useState(initialGameState);

  const calculateGananciaPorClick = (tacoId) => {
    const taco = gameState[tacoId];
    if (!taco) return 0;
    const multiplicadorBase = 1;
    const bonusPorMejoras = taco.upgrades.reduce((total, mejora) => total + (mejora.nivel * mejora.efecto), 0);
    return taco.precioBase * (multiplicadorBase + bonusPorMejoras);
  };

  const totalTps = useMemo(() => {
    return Object.values(gameState).reduce((tpsTotal, taco) => {
      if (!taco.isUnlocked || !taco.ayudantes?.length) return tpsTotal;

      const base = taco.ayudantes.find(a => a.id.includes('ayudante-1'))?.nivel || 0;
      const multiplicador = taco.ayudantes.find(a => a.id.includes('ayudante-2'))?.nivel || 0;

      const tacoTps = base * Math.pow(2, multiplicador);
      return tpsTotal + tacoTps;
    }, 0);
  }, [gameState]);

  const totalTacos = useMemo(() => {
    return Object.values(gameState).reduce((total, taco) => total + taco.tacosVendidos, 0);
  }, [gameState]);

  useEffect(() => {
    if (totalTps === 0) return;
    const intervalId = setInterval(() => {
      const gananciaPorSegundo = totalTps * calculateGananciaPorClick('asada');
      setGameState(prev => ({
        ...prev,
        asada: {
          ...prev.asada,
          tacosVendidos: prev.asada.tacosVendidos + (totalTps / 10)
        }
      }));
      setDinero(prevDinero => prevDinero + (gananciaPorSegundo / 10));
    }, 100);
    return () => clearInterval(intervalId);
  }, [totalTps, gameState]);

  const handleVenderTaco = (tacoId) => {
    const ganancia = calculateGananciaPorClick(tacoId);
    setDinero(prevDinero => prevDinero + ganancia);
    setGameState(prev => ({
      ...prev,
      [tacoId]: {
        ...prev[tacoId],
        tacosVendidos: prev[tacoId].tacosVendidos + 1
      }
    }));
  };

  const handleComprar = (tacoId, itemId, itemType) => {
    const taco = gameState[tacoId];
    const items = taco[itemType];
    const item = items.find(i => i.id === itemId);

    if (dinero >= item.costo) {
      setDinero(dinero - item.costo);
      const nuevosItems = items.map(i => {
        if (i.id === itemId) {
          const nuevoNivel = i.nivel + 1;
          return { ...i, nivel: nuevoNivel, costo: Math.floor(i.costoBase * Math.pow(1.15, nuevoNivel)) };
        }
        return i;
      });
      setGameState(prev => ({ ...prev, [tacoId]: { ...prev[tacoId], [itemType]: nuevosItems } }));
    }
  };

  const handleUnlockTaco = (tacoId) => {
    const taco = gameState[tacoId];
    if (dinero >= taco.unlockCost) {
      setDinero(prevDinero => prevDinero - taco.unlockCost);
      setGameState(prev => ({
        ...prev,
        [tacoId]: { ...prev[tacoId], isUnlocked: true }
      }));
    }
  };

  return (
    <div className="App">
      <Header
        tacosVendidos={totalTacos}
        dinero={dinero}
        tps={totalTps}
      />
      <main className='game-container'>
        {Object.values(gameState).map(taco => (
          <div key={taco.id} className="taco-type-section">
            {taco.isUnlocked ? (
              <>
                <h2>{taco.nombre} ${calculateGananciaPorClick(taco.id).toFixed(2)}</h2>
                <ClickerButton
                  onVenderTaco={() => handleVenderTaco(taco.id)}
                  guisado={taco.nombre}
                />
                <UpgradeList
                  titulo={`Mejoras de ${taco.nombre}`}
                  upgrades={taco.upgrades}
                  onComprarMejora={(itemId) => handleComprar(taco.id, itemId, 'upgrades')}
                  dinero={dinero}
                />
                {taco.ayudantes.length > 0 && (
                  <AyudanteList
                    titulo={`Ayudantes de ${taco.nombre}`}
                    ayudantes={taco.ayudantes}
                    onComprarAyudante={(itemId) => handleComprar(taco.id, itemId, 'ayudantes')}
                    dinero={dinero}
                  />
                )}
              </>
            ) : (
              <div className="unlock-section">
                <h2>Desbloquear Taquería de {taco.nombre}</h2>
                <p>Costo: ${taco.unlockCost.toLocaleString()}</p>
                <button
                  className="unlock-button"
                  onClick={() => handleUnlockTaco(taco.id)}
                  disabled={dinero < taco.unlockCost}
                >
                  Desbloquear
                </button>
              </div>
            )}
          </div>
        ))}
      </main>
    </div>
  );
}
