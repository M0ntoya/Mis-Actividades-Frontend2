import {
  ParadoIzq, ParadoDer,
  AgachadoDer, AgachadoIzq,
  CaminarDer, CaminarIzq,
  SaltarIzq, SaltarDer,
  CaerIzq, CaerDer,
  AtaqueDer, AtaqueIzq
} from "./stateMachine/state.js";

import MundoFisico from "../fisica/mundo.js";
import global from "../global.js";

export default class Jugador {
  constructor(anchoJuego, altojuego) {
    this.anchoJuego = anchoJuego;
    this.altojuego = altojuego;

    this.mundo = MundoFisico.mundo;
    this.motor = MundoFisico.motor;

    this.estados = [
      new ParadoIzq(this), new ParadoDer(this),
      new AgachadoIzq(this), new AgachadoDer(this),
      new CaminarIzq(this), new CaminarDer(this),
      new SaltarIzq(this), new SaltarDer(this),
      new CaerIzq(this), new CaerDer(this),
      new AtaqueDer(this), new AtaqueIzq(this)
    ];
    this.estadoActual = this.estados[1];

    this.spriteSheet = document.getElementById("paradoDerecha");
    this.anchoSprite = 42;
    this.altoSprite = 64;
    this.columna = 0;
    this.fila = 0;
    this.maxFrames = 3;
    this.FPS = 8;
    this.frameTimer = 0;
    this.ajusteTiempo = 1000 / this.FPS;
    this.caerEstilo = false;
    this.direccionCaida = 0;
    this.anchoColisionador = this.anchoSprite - 10;

    this.x = 100;
    this.y = 260;

    this.velocidad = 0;
    this.maxVelocidad = 4;
    this.maxVelocidadSalto = -6;
    this.velocidadSalto = 0;
    this.gravedad = 750;
    this.saltando = false;

    this.cuerpo = Matter.Bodies.rectangle(
      this.x + this.anchoSprite / 2,
      this.y + this.altoSprite / 2,
      this.anchoColisionador,
      this.altoSprite,
      {
        label: "jugador",
        inertia: Infinity,
        friction: 0.1,
        frictionAir: 0.02,
        restitution: 0.02,
        width: this.anchoColisionador,
        height: this.altoSprite,
      }
    );

    Matter.Body.setStatic(this.cuerpo, false);
    Matter.World.add(this.mundo, this.cuerpo);

    //inicializamos protección por daño
    this.invulnerableHasta = 0;
  }

  draw(context) {
    context.drawImage(
      this.spriteSheet,
      this.columna * this.anchoSprite,
      this.fila * this.altoSprite,
      this.anchoSprite,
      this.altoSprite,
      this.x,
      this.y,
      this.anchoSprite,
      this.altoSprite
    );
  }

  update(input, dt) {
    if (this.estadoActual.update) {
      this.estadoActual.update(dt);
    }

    if (this.frameTimer > this.ajusteTiempo) {
      this.columna = (this.columna < this.maxFrames - 1) ? this.columna + 1 : 0;
      this.frameTimer = 0;
    } else {
      this.frameTimer += dt;
    }

    this.estadoActual.handleInput(input);

    this.x = Math.round(this.cuerpo.position.x - this.anchoSprite / 2);
    this.y = this.cuerpo.position.y - this.altoSprite / 2;

    this.detectarColision();
    this.detectarFantasma(); // NUEVO
  }

  setState(estado) {
    this.columna = 0;
    if (this.estadoActual.exit) this.estadoActual.exit();
    this.estadoActual = this.estados[estado];
    this.estadoActual.enter();
    this.ajusteTiempo = 1000 / this.FPS;
  }

  enSuelo() {
    let chocado = false;
    this.mundo.bodies.forEach(element => {
      if (element.label !== "jugador" && element.tipo === "piso") {
        let choquesitos = Matter.Collision.collides(this.cuerpo, element);
        if (choquesitos)
          chocado = choquesitos.collided;
      }
    });
    return chocado;
  }

  detectarColision() {
    this.mundo.bodies.forEach(element => {
      if (element.label !== "jugador" && element.tipo === "moneda") {
        let colisionColeccionable = Matter.Collision.collides(this.cuerpo, element);
        let moneda = element.entidad;
        if (colisionColeccionable) {
          global.agregarMonedas(moneda.valor);
          moneda.remover();
        }
      }
    });
  }
  // un pequeño empuje del jugador cuando colisiona con el fantasma
  // para simular un knockback
  aplicarKnockback(origenX) {
    const direccion = this.cuerpo.position.x < origenX ? -1 : 1;
    Matter.Body.setVelocity(this.cuerpo, {
      x: direccion * 200,
      y: -5,
    });

    this.ralentizadoHasta = Date.now() + 500;
  }



  //detección de colisión con fantasma
  detectarFantasma() {
    const ahora = Date.now();
    if (ahora < this.invulnerableHasta) return;

    this.mundo.bodies.forEach(element => {
      if (element.label === "fantasma") {
        let colision = Matter.Collision.collides(this.cuerpo, element);
        if (colision) {
          global.restarVida();
          this.invulnerableHasta = ahora + 800; // 0.8 segundos de invulnerabilidad
        }
      }
    });
  }
}
