import mundoFisico from "../fisica/mundo.js";

export default class Fantasma {
    constructor(x = 500, y = 265) {
        this.anchoJuego = 640;
        this.altoJuego = 360;

        // Spritesheet
        this.spriteSheet = document.getElementById("fantasmaIdle");
        this.anchoSprite = 45;
        this.altoSprite = 60;
        this.columna = 0;
        this.fila = 0;
        this.maxFrames = 6;
        this.FPS = 8;
        this.frameTimer = 0;
        this.ajusteTiempo = 1000 / this.FPS;

        // Lógica propia
        this.tipo = "enemigo";
        this.activo = true;
        this.vida = 3;

        // Posición inicial
        this.x = x;
        this.y = y;

        this.mundo = mundoFisico.mundo;
        this.motor = mundoFisico.motor;

        // Crear cuerpo físico
        this.cuerpo = Matter.Bodies.rectangle(
            this.x + this.anchoSprite / 2,
            this.y + this.altoSprite / 2,
            this.anchoSprite,
            this.altoSprite,
            {
                label: "fantasma", // ✅ Necesario para detectar colisiones
                inertia: Infinity,
                friction: 0.1,
                frictionAir: 0.02,
                restitution: 0.02,
                tipo: this.tipo,
                isStatic: false
            }
        );

        Matter.World.add(this.mundo, this.cuerpo);
        this.cuerpo.entidad = this;

        // Movimiento oscilante
        this.tiempo = 0;
        this.origenX = this.cuerpo.position.x;
        this.origenY = this.cuerpo.position.y;
    }

    update(dt) {
        // Frame animación
        this.frameTimer += dt;
        if (this.frameTimer > this.ajusteTiempo) {
            this.columna = (this.columna + 1) % this.maxFrames;
            this.frameTimer = 0;
        }

        // Movimiento de vaivén
        this.tiempo += dt;
        const amplitud = 2;
        const velocidad = 0.25;

        const nuevoX = this.origenX +
            Math.sin(this.tiempo * (velocidad * Math.PI / 180)) * amplitud;

        const nuevoY = this.origenY +
            Math.cos(this.tiempo * (velocidad * Math.PI / 180)) * amplitud;

        Matter.Body.setPosition(this.cuerpo, {
            x: nuevoX,
            y: nuevoY
        });

        // Sincronizar con sprite
        this.x = Math.round(nuevoX - this.anchoSprite / 2);
        this.y = Math.round(nuevoY - this.altoSprite / 2);
    }

    draw(context) {
        context.drawImage(
            this.spriteSheet,
            this.columna * this.anchoSprite,
            this.fila * this.altoSprite,
            this.anchoSprite,
            this.altoSprite,
            this.x,
            this.y,
            this.anchoSprite,
            this.altoSprite
        );
    }

    recibirDanio(danio) {
        if (this.vida > 0) {
            this.vida -= danio;
            console.log(`Fantasma recibió ${danio} de daño. Vida restante: ${this.vida}`);
        }

        if (this.vida <= 0 && this.activo) {
            Matter.World.remove(this.mundo, this.cuerpo);
            this.activo = false;
        }
    }
}
