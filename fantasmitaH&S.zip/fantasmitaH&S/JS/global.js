class Global {
  constructor() {
    this.monedas = 0; // Cantidad de monedas del jugador
    this.vidas = 3;   // Número de vidas del jugador

    this.stopLoop = null; // Se asignará desde main.js
  }

  agregarMonedas(cantidad) {
    this.monedas += cantidad;
    this.actualizarHUD();
  }

  restarVida() {
    if (this.vidas > 0) {
      this.vidas--;
      this.actualizarHUD();

      if (this.vidas === 0) {
        this.gameOver();
      }
    }
  }

  actualizarHUD() {
    const vidasElemento = document.getElementById('vidas');
    const monedasElemento = document.getElementById('monedas');
    if (vidasElemento) vidasElemento.innerText = `❤️ x ${this.vidas}`;
    if (monedasElemento) monedasElemento.innerText = `💰 x ${this.monedas}`;
  }

  gameOver() {
    // Mostrar mensaje
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = 0;
    overlay.style.left = 0;
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.background = 'rgba(0,0,0,0.85)';
    overlay.style.display = 'flex';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';
    overlay.style.color = 'white';
    overlay.style.fontSize = '3rem';
    overlay.style.zIndex = 1000;
    overlay.innerText = 'GAME OVER';

    document.body.appendChild(overlay);

    // Detener el bucle principal
    if (this.stopLoop) {
      this.stopLoop();
    }
  }
}

export default new Global(); // Singleton
