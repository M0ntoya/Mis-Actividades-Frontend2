// main.js — Punto de entrada del juego

// 1. Importaciones de módulos
import Jugador from "./Clases/jugador.js";
import InputHandler from "./Clases/stateMachine/input.js";
import Mapa from "./Clases/mapa.js";
import Fantasma from "./Clases/fantasma.js";
import mundoFisico from "./fisica/mundo.js";
import global from "./global.js";

// 2. Esperar a que todo el DOM esté cargado.
window.onload = function () {
  // ───────── Configuración básica del canvas ─────────
  const canvas = document.getElementById("canvas");
  const context = canvas.getContext("2d");
  const gameWidth = canvas.width;
  const gameHeight = canvas.height;

  let tiempoInicio = 0;

  // ───────── Instancias principales ─────────
  const mapa = new Mapa();
  const jugador = new Jugador(gameWidth, gameHeight);
  const fantasma = new Fantasma(); // Puedes cambiar posición si lo deseas
  const input = new InputHandler();

  // ───────── HUD inicial ─────────
  global.actualizarHUD();

  // ───────── Control de fin de juego ─────────
  let detenido = false;
  global.stopLoop = () => {
    detenido = true;
  };

  // ───────── Invulnerabilidad ─────────
  let invulnerableUntil = 0;

  // Detectar colisiones entre jugador y fantasma
  Matter.Events.on(mundoFisico.motor, "collisionStart", function (evento) {
    evento.pairs.forEach(pair => {
      const labels = [pair.bodyA.label, pair.bodyB.label];

      if (labels.includes("jugador") && labels.includes("fantasma")) {
        const ahora = Date.now();
        if (ahora > invulnerableUntil) {
          global.restarVida();
          invulnerableUntil = ahora + 800; // 0.8 segundos de invulnerabilidad

          // Obtener referencia al cuerpo del jugador
          const jugadorBody = pair.bodyA.label === "jugador" ? pair.bodyA : pair.bodyB;
          const fantasmaBody = pair.bodyA.label === "fantasma" ? pair.bodyA : pair.bodyB;

          // Aplicar knockback
          jugador.aplicarKnockback(fantasmaBody.position.x);
        }
      }

    });
  });

  // ───────── Lógica de actualización ─────────
  function update(dt) {
    if (detenido) return;

    jugador.update(input.keys, dt);
    fantasma.update(dt);
    mapa.update(dt);
  }

  function draw() {
    if (detenido) return;

    context.clearRect(0, 0, gameWidth, gameHeight);

    // 1. Dibujar el fondo
    mapa.dibujarMapa(context);

    // 2. Dibujar entidades
    jugador.draw(context);
    fantasma.draw(context);
  }

  function gameLoop(time) {
    if (detenido) return;

    const deltaTime = time - tiempoInicio;
    tiempoInicio = time;

    update(deltaTime);
    draw();

    requestAnimationFrame(gameLoop);
  }

  requestAnimationFrame(gameLoop);
};
